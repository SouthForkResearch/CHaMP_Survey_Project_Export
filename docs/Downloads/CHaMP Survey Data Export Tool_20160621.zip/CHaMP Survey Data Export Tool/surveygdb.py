﻿# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# Name:        CHaMP Survey Geodatabase Functions and Definitions             #
# Purpose:     Developed for CHaMP GIS Tools                                  #
#                                                                             #
# Author:      Kelly Whitehead                                                #
#              South Fork Research, Inc.                                      #
#              Seattle Washington                                             #
#                                                                             #
# Created:     2012-05-02                                                     #
# Version:     13.15                                                          #
# Modified:    2013-09-12                                                     #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#!/usr/bin/env python

# # Import Modules # #
import arcpy
import sys
import os
import time
import check
import CHaMP

# # Survey GeoDataBase Definitions # #
fcTopoPointsCodes = ['tp###','tb','to','bl','wg','bf','in','out','q','u##','swg']
fcControlPointsCodes = ['cp###','bm###',"bos","tos"]
fcEdgeofWaterPoints = ['lw','rw','mw','br']
fcStreamFeatures = ['ws','z####','']
fcBreaklinesHard = ['tb','to','bl','bf']
fcBreaklinesSoft = ['wg','lw','rw','mw','br','swg']
fcBreaklinesNone = ['%']
listFCPointNames = ["Topo_Points","Control_Points","EdgeofWater_Points","Stream_Features"]

versionGDB = CHaMP.versionGDB
toolVersion = '14.00'
year = 2015

# # # Fuctions  # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#-------------------------------------------------------------------------------
def version():
    pass
    return versionGDB
#-------------------------------------------------------------------------------
def CHaMPtoolVersion():
    pass
    return str(toolVersion)
#-------------------------------------------------------------------------------
def inputsurvey(fileName):
    descFile = arcpy.Describe(fileName)
    descParentFile = arcpy.Describe(descFile.path)
    #descParentFile2 = arcpy.Describe(descParentFile.path)

    # Shapefiles #
    if descFile.dataType == "ShapeFile":
        #workspace = descFile.path
        inputFileName = descFile.name
        spatialReference = descFile.spatialReference

    # GDB Feature Class #
    elif descFile.dataType == 'FeatureClass':
        #workspace = descParentFile2.path
        inputFileName = descParentFile.name
        spatialReference = descFile.spatialReference

    # DXF Files #
    elif descParentFile.dataType == "CadDrawingDataset":
        #workspace = descParentFile.path
        inputFileName = descParentFile.name
        spatialReference = descParentFile.spatialReference

    return inputFileName,spatialReference
#-------------------------------------------------------------------------------
def pointcodelist(FDS = "NONE"):
    listCodes = []
    listCodes.append(fcTopoPointsCodes)
    listCodes.append(fcControlPointsCodes)
    listCodes.append(fcEdgeofWaterPoints)
    listCodes.append(fcStreamFeatures)
    if FDS == "NONE":
        names = listFCPointNames
    else:
        names = []
        for name in listFCPointNames:
            newname = FDS + "\\" + name
            names.append(newname)
    return names,listCodes
#-------------------------------------------------------------------------------
def linecodelist(lineType):
    if lineType == "HARD":
        listLineCodes = fcBreaklinesHard
    elif lineType == "SOFT":
        listLineCodes = fcBreaklinesSoft
    elif lineType == "NONE":
        listLineCodes = fcBreaklinesNone
    elif lineType == "ALL":
        listLineCodes = []
        for code in fcBreaklinesHard:
            listLineCodes.append(code)
        for code in fcBreaklinesSoft:
            listLineCodes.append(code)
        for code in fcBreaklinesNone:
            listLineCodes.append(code)
    else:
        listLineCodes = []
    return listLineCodes
#-------------------------------------------------------------------------------
def addpointFC(OutputLocation,InputPoints,FeatureClassName,CodeList,strCodeField,strPointNumberField):
    wherestatement = "("
    codeField = arcpy.AddFieldDelimiters(InputPoints,strCodeField)
    for code in CodeList:
        code = code.replace("#","%")
        wherestatement = wherestatement + 'LOWER(' + codeField + ') LIKE \'' + code + '\' OR '
    wherestatement = wherestatement.strip(' OR ')
    wherestatement = wherestatement + ') AND CHAR_LENGTH(' + codeField + ') <= 6'
    arcpy.MakeFeatureLayer_management(InputPoints,"TEMP",wherestatement)

    check.lockrelease(OutputLocation)
    FC = arcpy.CreateFeatureclass_management(OutputLocation,FeatureClassName,"POINT",'',"DISABLED","ENABLED")

    check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
    arcpy.AddField_management(FC,"DESCRIPTION","TEXT","","",6)

    fieldPointNumber = arcpy.ListFields(InputPoints,strPointNumberField)[0]

    check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
    arcpy.AddField_management(FC,"VDE","DOUBLE")
    check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
    arcpy.AddField_management(FC,"HDE","DOUBLE")
    check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
    arcpy.AddField_management(FC,"POINT_QUALITY","DOUBLE")
    check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
    arcpy.AddField_management(FC,"STATION","TEXT","","",5)

    if fieldPointNumber.type == "String":

        check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
        arcpy.AddField_management(FC,strPointNumberField,"TEXT","","",10)

    if fieldPointNumber.type == "Integer":

        check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
        arcpy.AddField_management(FC,strPointNumberField,"LONG")

    if fieldPointNumber.type == "SmallInteger":
        check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
        arcpy.AddField_management(FC,strPointNumberField,"SHORT")

    if strCodeField == "DESCRIPTION":
        check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
        arcpy.Append_management("TEMP",FC,"NO_TEST")
    else:
        check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
        arcpy.AddField_management(FC,strCodeField,"TEXT","","",6)
        check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
        arcpy.Append_management("TEMP",FC,"NO_TEST")
        arcpy.CalculateField_management(FC,"DESCRIPTION","!" + strCodeField + "!.lower()","PYTHON")
        check.lockrelease(str(OutputLocation) + '\\' + str(FeatureClassName))
        arcpy.DeleteField_management(FC,strCodeField)
    arcpy.Delete_management("TEMP")
    return True
#-------------------------------------------------------------------------------
def controlPoints(inputControlPoints):
    # Add Layer
    lyrControl = "CONTROLPOINTSTEMP"
    
    # Add Fields
    check.lockrelease(inputControlPoints)
    arcpy.AddField_management(inputControlPoints,"Type","TEXT",'','',10)
    check.lockrelease(inputControlPoints)
    arcpy.AddField_management(inputControlPoints,"Source","TEXT",'','',15)
    check.lockrelease(inputControlPoints)
    arcpy.AddField_management(inputControlPoints,"VDE","DOUBLE")
    check.lockrelease(inputControlPoints)
    arcpy.AddField_management(inputControlPoints,"HDE","DOUBLE")
    check.lockrelease(inputControlPoints)
    arcpy.AddField_management(inputControlPoints,"POINT_QUALITY","DOUBLE")
    check.lockrelease(inputControlPoints)
    arcpy.AddField_management(inputControlPoints,"STATION","TEXT","","",5)

    arcpy.MakeFeatureLayer_management(inputControlPoints,lyrControl)
    arcpy.SelectLayerByAttribute_management(lyrControl,"NEW_SELECTION",'LOWER("DESCRIPTION") LIKE' + "'bm%'")
    arcpy.CalculateField_management(lyrControl,"Type","'Benchmark'","PYTHON")
    arcpy.SelectLayerByAttribute_management(lyrControl,"NEW_SELECTION",'LOWER("DESCRIPTION") LIKE' + "'cp%'")
    arcpy.CalculateField_management(lyrControl,'Type',"'Control'","PYTHON")
    arcpy.SelectLayerByAttribute_management(lyrControl,"NEW_SELECTION","""LOWER("DESCRIPTION") LIKE 'bos' OR LOWER("DESCRIPTION") LIKE 'tos'""")
    arcpy.CalculateField_management(lyrControl,'Type',"'Marker'","PYTHON")
##    arcpy.SelectLayerByAttribute_management(lyrControl,"NEW_SELECTION",'LOWER("DESCRIPTION") LIKE '+ "'%*'")
##    arcpy.CalculateField_management(lyrControl,"Source","Imported","PYTHON")
##    arcpy.SelectLayerByAttribute_management(lyrControl,"SWITCH_SELECTION")
##    arcpy.CalculateField_management(lyrControl,"Source","'Surveyed'","PYTHON")
    check.lockrelease(lyrControl)
    arcpy.Delete_management(lyrControl)
    return 1
#-------------------------------------------------------------------------------
def addErrorFC(FDS,inputFC,errorFCName):

    fcType = arcpy.Describe(inputFC).shapeType
    descFDS = arcpy.Describe(FDS)
    check.lockrelease(descFDS.path)
    arcpy.env.workspace = descFDS.path
    fclist = arcpy.ListFeatureClasses("*",fcType,descFDS.name)
    arcpy.MakeFeatureLayer_management(inputFC,"TEMP")
    arcpy.SelectLayerByAttribute_management("TEMP","NEW_SELECTION") #all features
    for featureclass in fclist:
        arcpy.SelectLayerByLocation_management("TEMP","INTERSECT",featureclass,"","REMOVE_FROM_SELECTION")
    check.lockrelease(FDS)

    errorFC = str(FDS) + "\\" + errorFCName

    if fcType == "Point":
        if int(arcpy.GetCount_management("TEMP").getOutput(0))==0:
            if descFDS.name == "Projected":
                arcpy.CopyFeatures_management(str(FDS) + "\\Topo_Points",errorFC)
            elif descFDS.name == "Unprojected":
                arcpy.CopyFeatures_management(str(FDS) + "\\Topo_Points_Unprojected",errorFC)
            check.lockrelease(FDS)
            arcpy.DeleteRows_management(errorFC)
        else:
            arcpy.CreateFeatureclass_management(FDS,errorFCName,fcType,'',"DISABLED","ENABLED")
            #Add Fields
            check.lockrelease(errorFC)
            arcpy.AddField_management(errorFC,"DESCRIPTION","TEXT","","",25)
            check.lockrelease(errorFC)
            arcpy.AddField_management(errorFC,"VDE","DOUBLE")
            check.lockrelease(errorFC)
            arcpy.AddField_management(errorFC,"HDE","DOUBLE")
            check.lockrelease(errorFC)
            arcpy.AddField_management(errorFC,"POINT_QUALITY","DOUBLE")
            check.lockrelease(errorFC)
            arcpy.AddField_management(errorFC,"STATION","TEXT","","",5)
    else:
        if int(arcpy.GetCount_management("TEMP").getOutput(0))==0:
            if descFDS.name == "Projected":
                arcpy.CopyFeatures_management(str(FDS) + "\\Breaklines",errorFC)
            elif descFDS.name == "Unprojected":
                arcpy.CopyFeatures_management(str(FDS) + "\\Breaklines_Unprojected",errorFC)
            check.lockrelease(FDS)
            arcpy.DeleteRows_management(errorFC)
        else: 
            arcpy.CreateFeatureclass_management(FDS,errorFCName,fcType,'',"DISABLED","ENABLED")


    # Load Error FC
    check.lockrelease(errorFC)
    arcpy.Append_management("TEMP",errorFC,"NO_TEST")
    addErrorFields(errorFC)
    check.lockrelease(errorFC)
    arcpy.CalculateField_management(errorFC,"ErrorType",'"Invalid Code"')
    check.lockrelease(errorFC)
    arcpy.CalculateField_management(errorFC,"OriginalLocation",'"Imported Data"')
    arcpy.Delete_management("TEMP")
    return True

def addErrorFields(errorFC):
    if not len(arcpy.ListFields(errorFC,"ErrorType"))==1:
        check.lockrelease(errorFC)
        arcpy.AddField_management(errorFC,"ErrorType",'TEXT',"","","25","","","","")
    if not len(arcpy.ListFields(errorFC,"OriginalLocation"))==1:
        check.lockrelease(errorFC)
        arcpy.AddField_management(errorFC,"OriginalLocation","TEXT","","","25","","","","")
    return
#-------------------------------------------------------------------------------
def addTables(GDB):
    tableQaQcVectorName = 'QaQcVector'
    fieldsQaQcVector = ['TIMESTAMP','TopoZmin','TopoZmax','TopoZmean','TopoZsd','TopoZrange','bfZmin','bfZmax','bfZmean','bfZsd','bfZrange','waterZmin','waterZmax','waterZmean','waterZsd','waterZrange']
    typesQaQcVector = ['TEXT','FLOAT','FLOAT','FLOAT','FLOAT','FLOAT','FLOAT','FLOAT','FLOAT','FLOAT','FLOAT','FLOAT','FLOAT','FLOAT','FLOAT','FLOAT']
    textlengthQaQcVector = [30,'','','','','','','','','','','','','','','']

    tableQaQcPointsName = 'QaQcPoints'
    fieldsQaQcPoints = ['TIMESTAMP','Code','Count','Unique']
    typesQaQcPoints = ['TEXT','TEXT','SHORT','SHORT']
    textlengthQaQcPoints = [30,7,'','']

    tableQaQcLinesName = 'QaQcLines'
    fieldsQaQcLines = ['TIMESTAMP','Code','Count','Length']
    typesQaQcLines = ['TEXT','TEXT','SHORT','FLOAT']
    textlengthQaQcLines = [30,7,'','']

    tableQaQcTINName = 'QaQcTIN'
    fieldsQaQcTIN = ['TIMESTAMP','TIN_Name','BL_Count','BL_Length','BL_Crossed','Dams','Node_Count','Node_Zmin','Node_Zmax','Nodes_Topo','Removed_Topo','Nodes_Interpolated','Nodes_EditedZ','Facets','Needs_Attention','Notes']
    typesQaQcTIN = ['TEXT','TEXT','SHORT','FLOAT','TEXT','TEXT','SHORT','FLOAT','FLOAT','SHORT','SHORT','SHORT','SHORT','TEXT','TEXT','TEXT']
    textlengthQaQcTIN = [30,15,'','',7,7,'','','','','','','',7,7,500]

    tableQaQcPolygonsName = "QaQcPolygons"
    fieldsQaQcPolygons = ['TIMESTAMP','SurveyExtentCount','WaterExtentCount','ChannelUnitsCount','ChannelUnitsUnique']
    typesQaQcPolygons = ['TEXT','SHORT','SHORT','SHORT','SHORT']
    textlengthQaQcPolygons = [30,'','','','']

    tableInfoSurveyName = 'SurveyInfo'
    fieldsInfoSurvey = ['SiteID','Watershed','VisitType','SurveyInstrument','Projection','SurveyFile','CHaMPGISversion','SurveyGDBversion',"ImportDate","StreamName","Variability","InstrumentModel","Organization","Crew","CoordinateType","ProtocolType"]
    typesInfoSurvey = ['TEXT','TEXT','TEXT','TEXT','TEXT','TEXT','TEXT',"TEXT","TEXT","TEXT","TEXT","TEXT",'TEXT','TEXT',"TEXT","TEXT"]
    textlengthInfoSurvey = [255,25,25,25,25,255,10,10,30,25,10,30,30,30,30,30]

    tableQaQcLogName = 'Log'
    fieldsQaQcLog = ["TIMESTAMP","ToolName","Status","Message"]
    typesQaQcLog = ['TEXT',"TEXT","TEXT","TEXT"]
    textlengthQaQcLog = [30,20,10,1000]

    tableQaQcSurveyName = 'QaQcSurvey'
    fieldsQaQcSurvey = []
    typesQaQcSurvey = []
    textlengthQaQcSurvey = []

    check.lockrelease(GDB)
    tableQaQcLog = arcpy.CreateTable_management(GDB,tableQaQcLogName)
    check.lockrelease(GDB)
    tableInfoSurvey = arcpy.CreateTable_management(GDB,tableInfoSurveyName)
    check.lockrelease(GDB)
    tableQaQcVector = arcpy.CreateTable_management(GDB,tableQaQcVectorName)
    check.lockrelease(GDB)
    tableQaQcPoints = arcpy.CreateTable_management(GDB,tableQaQcPointsName)
    check.lockrelease(GDB)
    tableQaQcLines = arcpy.CreateTable_management(GDB,tableQaQcLinesName)
    check.lockrelease(GDB)
    tableQaQcTIN = arcpy.CreateTable_management(GDB,tableQaQcTINName)
    check.lockrelease(GDB)
    tableQaQcPolygons = arcpy.CreateTable_management(GDB,tableQaQcPolygonsName)
    check.lockrelease(GDB)
    tableQaQcSurvey = arcpy.CreateTable_management(GDB,tableQaQcSurveyName)

    for field, type, length in zip(fieldsQaQcVector,typesQaQcVector,textlengthQaQcVector):
        check.lockrelease(GDB)
        arcpy.AddField_management(tableQaQcVector,field,type,'','',length)
    for field, type, length in zip(fieldsQaQcPoints,typesQaQcPoints,textlengthQaQcPoints):
        check.lockrelease(GDB)
        arcpy.AddField_management(tableQaQcPoints,field,type,'','',length)
    for field, type, length in zip(fieldsQaQcLines,typesQaQcLines,textlengthQaQcLines):
        check.lockrelease(GDB)
        arcpy.AddField_management(tableQaQcLines,field,type,'','',length)
    for field, type, length in zip(fieldsQaQcTIN,typesQaQcTIN,textlengthQaQcTIN):
        check.lockrelease(GDB)
        arcpy.AddField_management(tableQaQcTIN,field,type,'','',length)
    for field, type, length in zip(fieldsInfoSurvey,typesInfoSurvey,textlengthInfoSurvey):
        check.lockrelease(GDB)
        arcpy.AddField_management(tableInfoSurvey,field,type,'','',length)
    for field, type, length in zip(fieldsQaQcPolygons,typesQaQcPolygons,textlengthQaQcPolygons):
        check.lockrelease(GDB)
        arcpy.AddField_management(tableQaQcPolygons,field,type,'','',length)
    for field, type, length in zip(fieldsQaQcLog,typesQaQcLog,textlengthQaQcLog):
        check.lockrelease(GDB)
        arcpy.AddField_management(tableQaQcLog,field,type,'','',length)
    for field, type, length in zip(fieldsQaQcSurvey,typesQaQcSurvey,textlengthQaQcSurvey):
        check.lockrelease(GDB)
        arcpy.AddField_management(tableQaQcSurvey,field,type,'','',length)

    return True

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

if __name__ == '__main__':
    pass
